﻿namespace Refactoring_08_Calculator.DiscountStrategy
{
    public interface IContext
    {
        decimal CalculateDiscount();
    }
}