﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using EjemploLogin.Helpers.Authentication.Model;
using System;
using System.Threading.Tasks;

namespace EjemploLogin.Controllers
{
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> userStore;

        public LoginController(UserManager<ApplicationUser> userStore) {
            this.userStore = userStore;
        }

        [AllowAnonymous]
        [Route("api/login")]
        public async Task<string> Login([FromHeader] string userName, [FromHeader] string password)
        {
            var user = await userStore.FindByNameAsync(userName);

            if (user == null)
            {
                return null;
            }

            if (await userStore.CheckPasswordAsync(user, password))
            {
                return await userStore.GenerateUserTokenAsync(user, "PasswordlessLoginTotpProvider", "passwordless-auth");
            }
            else
            {
                return null;
            }
        }

        [AllowAnonymous]
        [Route("api/generateUser/{userName}/{password}")]
        public async Task<IdentityResult> GenerateUser(string userName, string password)
        {
            var user = await userStore.FindByNameAsync(userName);

            if (user == null)
            {
                var newUser = new ApplicationUser() { UserName = userName, SecurityStamp = Convert.ToBase64String(Guid.NewGuid().ToByteArray()) };
                return await userStore.CreateAsync(newUser, password);
            }
            return null;
        }
    }
}