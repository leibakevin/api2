﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.AspNetCore.Mvc.Filters;
using EjemploLogin.Helpers.Authentication.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EjemploLogin.Helpers.Authentication
{
    public class KrakoAuthFilter : Attribute, IAuthorizationFilter
    {
        private readonly UserManager<ApplicationUser> userStore;

        public KrakoAuthFilter(UserManager<ApplicationUser> userStore)
        {
            this.userStore = userStore;
        }


        public void OnAuthorization(AuthorizationFilterContext context)
        {
            if (!context.ActionDescriptor.FilterDescriptors.Any(fd => fd.Filter is AllowAnonymousFilter))
            {
                var token = context.HttpContext.Request.Headers["Authorization"].FirstOrDefault();
                var userName = context.HttpContext.Request.Headers["User"].FirstOrDefault() ?? "";
                var user = userStore.FindByNameAsync(userName).Result;

                if (user == null || token == null)
                {
                    context.Result = new UnauthorizedResult();
                }
                else
                {
                    var isValid = userStore.VerifyUserTokenAsync(user, "PasswordlessLoginTotpProvider", "passwordless-auth", token).Result;
                    if (!isValid)
                    {
                        context.Result = new UnauthorizedResult();
                    }
                }
            }
        }
    }
}
