﻿namespace EjemploLogin.Helpers.Authentication.Model
{
    public class ApplicationRole
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string NormalizedName { get; set; }
    }
}
